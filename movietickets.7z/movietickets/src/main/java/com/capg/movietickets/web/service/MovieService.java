package com.capg.movietickets.web.service;



import java.util.List;

import com.capg.movietickets.web.model.Movie1;

public interface MovieService {
	
	public void save(Movie1 movieId); 
	List<Movie1>getAllMovies();
	/*
	 * public String updatemovies (int movieId); public void delete (int movieId);
	 */
	public Movie1 findById(int id);

}
