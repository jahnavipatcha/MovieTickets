package com.capg.movietickets.web.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.movietickets.web.model.Booking1;
import com.capg.movietickets.web.model.Shows1;
import com.capg.movietickets.web.model.User1;
import com.capg.movietickets.web.repository.BookingRepository;
import com.capg.movietickets.web.repository.ShowRepository;
import com.capg.movietickets.web.repository.UserRepository;
import com.capg.movietickets.web.visualobjects.BookingVo;
import com.capg.movietickets.web.visualobjects.TicketsVO;

@Service
public class BookingSeviceImp implements BookingService {

	@Autowired
	BookingRepository bookingRepository;

	@Autowired
	ShowRepository showRepository;

	@Autowired
	UserRepository userRepository;

	@Override
	public Booking1 createBooking(BookingVo createbooking) {
		// TODO Auto-generated method stub

		Booking1 booking = new Booking1();
		User1 user = userRepository.findByUserId(createbooking.getUserId());
		Shows1 show = showRepository.findOne(createbooking.getShowId());

		booking.setUser(user);
		booking.setShows(show);
		booking.setTicketCount(createbooking.getNoOfTickets());

		booking = bookingRepository.save(booking);
		return booking;
	}

	@Override
	public Booking1 viewBookings(TicketsVO viewBooking) {
		// TODO Auto-generated method stub
		// return bookingRepository.view(viewBooking.getTicketId());
		return new Booking1();
	}

	/*
	 * @Override public Booking1 save(Booking1 bookingId) { // TODO Auto-generated
	 * method stub bookingrepository.save(bookingId); return
	 * bookingrepository.save(bookingId); }
	 * 
	 * @Override public List<Booking1> getBookings() { // TODO Auto-generated method
	 * stub return bookingrepository.findAll(); }
	 * 
	 * 
	 * @Override public void deleteBookings(long bookingId) {
	 * bookingrepository.delete(bookingId);
	 * 
	 * }
	 */
}
