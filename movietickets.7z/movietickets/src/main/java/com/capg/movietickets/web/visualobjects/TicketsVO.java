package com.capg.movietickets.web.visualobjects;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeName;

@JsonTypeName(value = "user")
@JsonTypeInfo(include = JsonTypeInfo.As.WRAPPER_OBJECT, use = JsonTypeInfo.Id.NAME)
public class TicketsVO {
	private int ticketId;
	//private List<TicketsVO> ticketsVO;
	private String ticketAvailability;
	
	
	public TicketsVO(int ticketId, List<TicketsVO> ticketsVO, String ticketAvailability) {
		super();
		this.ticketId = ticketId;
		//this.ticketsVO = ticketsVO;
		this.ticketAvailability = ticketAvailability;
	}
	
	public int getTicketId() {
		return ticketId;
	}
	public void setTicketId(int ticketId) {
		this.ticketId = ticketId;
	}

	/*
	 * public List<TicketsVO> getTicketsVO() { return ticketsVO; } public void
	 * setTicketsVO(List<TicketsVO> ticketsVO) { this.ticketsVO = ticketsVO; }
	 */
	public String getTicketAvailability() {
		return ticketAvailability;
	}
	public void setTicketAvailability(String ticketAvailability) {
		this.ticketAvailability = ticketAvailability;
	}
	
	

}
