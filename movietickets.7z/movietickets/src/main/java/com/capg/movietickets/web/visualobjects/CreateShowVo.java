package com.capg.movietickets.web.visualobjects;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "ticketAvailability", "movieId", "date", "time" })
public class CreateShowVo {

	@JsonProperty("ticketAvailability")
	private int ticketAvailability;
	@JsonProperty("movieId")
	private Integer movieId;
	@JsonProperty("date")
	private String date;
	@JsonProperty("time")
	private String time;

	@JsonProperty("ticketAvailability")
	public int getTicketAvailability() {
		return ticketAvailability;
	}

	@JsonProperty("ticketAvailability")
	public void setTicketAvailability(int ticketAvailability) {
		this.ticketAvailability = ticketAvailability;
	}

	@JsonProperty("movieId")
	public Integer getMovieId() {
		return movieId;
	}

	@JsonProperty("movieId")
	public void setMovieId(Integer movieId) {
		this.movieId = movieId;
	}

	@JsonProperty("date")
	public String getDate() {
		return date;
	}

	@JsonProperty("date")
	public void setDate(String date) {
		this.date = date;
	}

	@JsonProperty("time")
	public String getTime() {
		return time;
	}

	@JsonProperty("time")
	public void setTime(String time) {
		this.time = time;
	}

	public String getShowId() {
		// TODO Auto-generated method stub
		return null;
	}

}