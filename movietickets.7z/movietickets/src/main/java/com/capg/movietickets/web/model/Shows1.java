package com.capg.movietickets.web.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity(name = "shows")
public class Shows1 {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int showId;
	private String movieDate;
	private int ticketsAvailability;
	private String time;

	@OneToMany(mappedBy = "bookingId", fetch = FetchType.EAGER)
	private List<Booking1> bookings;

	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "movieId")
	private Movie1 movie;

	public Shows1(int i, String string, String string2, int j) {
		// TODO Auto-generated constructor stub
	}

	public Shows1() {

	}

	public int getShowId() {
		return showId;
	}

	public void setShowId(int showId) {
		this.showId = showId;
	}

	public List<Booking1> getBookings() {
		return bookings;
	}

	public void setBookings(List<Booking1> bookings) {
		this.bookings = bookings;
	}

	public Movie1 getMovie() {
		return movie;
	}

	public void setMovie(Movie1 movie) {
		this.movie = movie;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getMovieDate() {
		return movieDate;
	}

	public void setMovieDate(String movieDate) {
		this.movieDate = movieDate;
	}

	public int getTicketsAvailability() {
		return ticketsAvailability;
	}

	public void setTicketsAvailability(int ticketsAvailability) {
		this.ticketsAvailability = ticketsAvailability;
	}

}
