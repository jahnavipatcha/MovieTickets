package com.capg.movietickets.web.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.movietickets.web.model.Movie1;
import com.capg.movietickets.web.model.Shows1;
import com.capg.movietickets.web.repository.MovieRepository;
import com.capg.movietickets.web.repository.ShowRepository;
import com.capg.movietickets.web.visualobjects.CreateShowVo;

@Service
public class ShowsServiceImpl implements ShowsService {

	@Autowired
	ShowRepository showRepository;

	@Autowired
	MovieRepository movieRepository;

	@Override
	public Shows1 createShow(CreateShowVo createShow) {
		// TODO Auto-generated method stub

		Shows1 show = new Shows1();

		Movie1 movie = movieRepository.findOne(createShow.getMovieId());
		show.setMovie(movie);

		show.setTime(createShow.getTime());
		show.setMovieDate(createShow.getDate());
		show.setTicketsAvailability(createShow.getTicketAvailability());

		show = showRepository.save(show);
		return show;
	}

	@Override
	public Shows1 updateShow(CreateShowVo updateShow) {
		for (CreateShowVo show : retriveAll()) {
			if (show.getMovieId() == show.getMovieId()) {
				show.setTime(show.getTime());
				show.setDate(show.getDate());
				show.setTicketAvailability(show.getTicketAvailability());
			}
		}
		return updateShow(updateShow);

	}

	@Override
	public List<CreateShowVo> retriveAll() {

		Shows1 show1 = new Shows1(1, "10:00AM", "17/1/19", 300);
		Shows1 show2 = new Shows1(2, "11:00AM", "17/1/19", 200);
		Shows1 show3 = new Shows1(3, "12:00PM", "18/1/19", 100);
		showRepository.save(show1);
		showRepository.save(show2);
		showRepository.save(show3);
		List<Shows1> shows = showRepository.findAll();

		List<CreateShowVo> createShowsVo = new ArrayList<>();

		return createShowsVo;
	}

	@Override
	public void deleteShow(CreateShowVo deleteShow) {
		// TODO Auto-generated method stub
		//showRepository.delete(deleteShow.getShowId());
	}

	
}
