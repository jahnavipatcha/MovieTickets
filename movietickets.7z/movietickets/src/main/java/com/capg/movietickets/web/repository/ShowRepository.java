package com.capg.movietickets.web.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capg.movietickets.web.model.Shows1;

@Repository
public interface ShowRepository extends JpaRepository<Shows1, Integer> {

}
