package com.capg.movietickets.web.service;

import java.util.List;

import com.capg.movietickets.web.model.Shows1;
import com.capg.movietickets.web.visualobjects.CreateShowVo;

public interface ShowsService {

	

	public List<CreateShowVo> retriveAll();

	public Shows1 createShow(CreateShowVo createShow);

	public Shows1 updateShow(CreateShowVo updateShow);

	 public void deleteShow(CreateShowVo deleteShow);

	

	


}
