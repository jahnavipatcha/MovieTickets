package com.capg.movietickets.web.service;

import java.util.List;

import com.capg.movietickets.web.model.User1;

public interface UserService {

	public User1 save(User1 id);

	public void delete(int id);

	public List<User1> retriveAll();

	public User1 findById(int id);

	

}
