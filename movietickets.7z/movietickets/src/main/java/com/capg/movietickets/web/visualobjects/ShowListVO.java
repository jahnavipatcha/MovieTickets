package com.capg.movietickets.web.visualobjects;

import java.util.List;

import com.capg.movietickets.web.model.Booking1;



public class ShowListVO {
	
	private int showId;
	private String userName;
	private String movieName;
	private String showTime;
	private String date;

	private List<ShowListVO> showListVO;
	
	private int ticketsAvailability;
	
	private List<Booking1> bookings;
	
	
	


	public ShowListVO(int showId, String userName, String movieName, String showTime, String date) {
		super();
		this.showId = showId;
		this.userName = userName;
		this.movieName = movieName;
		this.showTime = showTime;
		this.date = date;
	}

	public List<ShowListVO> getShowListVO() {
		return showListVO;
	}

	public void setShowListVO(List<ShowListVO> showListVO) {
		this.showListVO = showListVO;
	}
	public int getTicketsAvailability() {
		return ticketsAvailability;
	}
	public void setTicketsAvailability(int ticketsAvailability) {
		this.ticketsAvailability = ticketsAvailability;
	}
	
	
	public int getShowId() {
		return showId;
	}

	public void setShowId(int showId) {
		this.showId = showId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getMovieName() {
		return movieName;
	}

	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}

	public String getShowTime() {
		return showTime;
	}

	public void setShowTime(String showTime) {
		this.showTime = showTime;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public List<Booking1> getBookings() {
		return bookings;
	}
	public void setBookings(List<Booking1> bookings) {
		this.bookings = bookings;
	}
	
	
	

}
