package com.capg.movietickets.web.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capg.movietickets.web.model.Movie1;

@Repository
public interface MovieRepository extends JpaRepository<Movie1, Integer>{
	
	/*@Transactional
	@Modifying
	@Query("UPDATE Movies m SET m.moviename = :movieName WHERE m.movieId = :movieId")
	String updatemovienames(@Param("movieId") int movieId,@Param("movieName") String movieName);*/

	
}
