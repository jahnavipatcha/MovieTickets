package com.capg.movietickets.web.visualobjects;

import com.fasterxml.jackson.annotation.JsonProperty;

public class BookingVo {

	@JsonProperty("userId")
	int userId;

	@JsonProperty("showId")
	int showId;

	@JsonProperty("noOfTickets")
	int noOfTickets;

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public int getShowId() {
		return showId;
	}

	public void setShowId(int showId) {
		this.showId = showId;
	}

	public int getNoOfTickets() {
		return noOfTickets;
	}

	public void setNoOfTickets(int noOfTickets) {
		this.noOfTickets = noOfTickets;
	}

}
