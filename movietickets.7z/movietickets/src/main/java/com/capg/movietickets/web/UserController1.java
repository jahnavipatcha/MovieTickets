package com.capg.movietickets.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capg.movietickets.web.model.Booking1;
import com.capg.movietickets.web.model.Movie1;
import com.capg.movietickets.web.model.Shows1;
import com.capg.movietickets.web.model.User1;
import com.capg.movietickets.web.service.BookingService;
import com.capg.movietickets.web.service.MovieService;
import com.capg.movietickets.web.service.ShowsService;
import com.capg.movietickets.web.service.UserService;
import com.capg.movietickets.web.visualobjects.BookingVo;
import com.capg.movietickets.web.visualobjects.CreateShowVo;
import com.capg.movietickets.web.visualobjects.TicketsVO;

@RestController
public class UserController1 {

	@Autowired
	private UserService userService;


	int count = 0;

	@RequestMapping("/")

	public String sayHello() {

		userService.save(new User1());
		return "Spring Boot is cool...";

	}

	@RequestMapping(value = "/user", method = RequestMethod.GET)
	public List<User1> save() {
		if (count == 0) {
			User1 user1 = new User1(1, "Aakanksha", "Ravutla", "dinnu123", "9177110567", "aakanksharavutla2@gmail.com");
			User1 user2 = new User1(2, "Shreya", "Kottam", "neethu123", "9182263315", "shreya@gmail.com");
			User1 user3 = new User1(3, "Saritha", "Gaddam", "sari123", "9440471612", "sari@gmail.com");
			/*
			 * ArrayList<User1> users = new ArrayList<User1>(); users.add(user1);
			 * users.add(user2); users.add(user3);
			 */
			userService.save(user1);
			userService.save(user2);
			userService.save(user3);
			count++;
		}
		return userService.retriveAll();
	}

	@RequestMapping(value = "/user/{id}", method = RequestMethod.GET)
	public User1 findUser(@PathVariable int id) {
		User1 user = userService.findById(id);
		return userService.findById(id);
	}

	@RequestMapping(value = "userdelete/{id}", method = RequestMethod.DELETE)
	public void delete(@PathVariable int id) {
		userService.delete(id);
	}

	// *****************************************SHOWS*******************************************************************

	@Autowired
	private ShowsService showsService;

	/*
	 * @RequestMapping(value = "/shows", method = RequestMethod.GET) public
	 * List<ShowListVO> findAllShowListVO() { if (count == 0) { ShowListVO shows1 =
	 * new ShowListVO(1, "Aakanksha", "KGF", "6:00AM tO 10:00PM", "1/10/19");
	 * ShowListVO shows2 = new ShowListVO(2, "Shreya", "Tiger", "6:30AM tO 10:30PM",
	 * "2/10/19"); ShowListVO shows3 = new ShowListVO(3, "Saritha", "Hello",
	 * "9:00AM tO 11:30PM", "2/10/19"); showsService.save(shows1);
	 * showsService.save(shows2); showsService.save(shows3); count++; } return
	 * showsService.retriveAll(); }
	 */

	@RequestMapping(value = "/shows", method = RequestMethod.POST)
	public Shows1 createShows(@RequestBody CreateShowVo createShow) {

		return showsService.createShow(createShow);
	}

	@RequestMapping(value = "/shows/{id}", method = RequestMethod.PUT)
	public Shows1 updateShows(CreateShowVo updateShow) {
		return showsService.updateShow(updateShow);
	}

	@RequestMapping(value = "/shows", method = RequestMethod.GET)
	public List<CreateShowVo> retriveAll() {
		return showsService.retriveAll();
	}

	@RequestMapping(value = "/shows/{id}", method = RequestMethod.DELETE)
	public void deleteShows(CreateShowVo deleteShow) {
		showsService.deleteShow(deleteShow);
	}

	//******************************************Bookings*************************************************************************
	

  @Autowired 
  private BookingService bookingService;
  
  @RequestMapping(value = "/bookings", method = RequestMethod.POST)
  public Booking1 createBooking(@RequestBody BookingVo createBooking) {
	  return bookingService.createBooking(createBooking);
  }
  
  
  
	
	 @RequestMapping(value="/bookings/{id}",method=RequestMethod.GET)
	 public Booking1 viewBookings(TicketsVO viewBooking) {
		 return bookingService.viewBookings(viewBooking);
	 }
	 
	 //*********************************************Movies*************************************
	 @Autowired 
	 private MovieService movieService;
	 
	 @RequestMapping(value="/movies",method = RequestMethod.GET)
	 public List<Movie1>findAll() {
		 Movie1 movie1=new Movie1(1,"KGF",50);
		 Movie1 movie2=new Movie1(2,"F2",80);
		 Movie1 movie3=new Movie1(3,"KICK",10);
		 
		 movieService.save(movie1);
		 movieService.save(movie2);
		 movieService.save(movie3);
		return movieService.getAllMovies();
	 
}
	 @RequestMapping(value = "/movies/{id}", method = RequestMethod.GET)
		public Movie1 findMovie(@PathVariable int id) {
			Movie1 movie = movieService.findById(id);
			return movieService.findById(id);
		}
}
  