package com.capg.movietickets.web.model;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity(name = "movies")
public class Movie1 {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int movieId;
	private String moviename;
	private int ticketsAvailability;
//	private List<Bookings> bookings;
	@JsonIgnore
	@OneToMany(mappedBy = "showId", fetch = FetchType.EAGER)
	private List<Shows1> shows;

	public Movie1() {
		super();
	}

	public Movie1(int movieId, String moviename, int ticketsAvailability) {
		super();
		this.movieId = movieId;
		this.moviename = moviename;
		this.ticketsAvailability = ticketsAvailability;
	}

	public List<Shows1> getShows() {
		return shows;
	}

	public void setShows(List<Shows1> shows) {
		this.shows = shows;
	}

	
	public int getMovieId() {
		return movieId;
	}

	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}

	public String getMoviename() {
		return moviename;
	}

	public void setMoviename(String moviename) {
		this.moviename = moviename;
	}

	public int getTicketsAvailability() {
		return ticketsAvailability;
	}

	public void setTicketsAvailability(int ticketsAvailability) {
		this.ticketsAvailability = ticketsAvailability;
	}

	/*
	 * @OneToMany(mappedBy = "movie") public List<Bookings> getBookings() { return
	 * bookings; }
	 * 
	 * public void setBookings(List<Bookings> bookings) { this.bookings = bookings;
	 * }
	 */

}
