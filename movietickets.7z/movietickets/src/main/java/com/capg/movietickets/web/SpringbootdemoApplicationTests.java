package com.capg.movietickets.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@EnableAutoConfiguration

public class SpringbootdemoApplicationTests 
{
    public static void main( String[] args )
    {
    	SpringApplication.run(SpringbootdemoApplicationTests.class, args);
    }
} 
