package com.capg.movietickets.web.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.movietickets.web.model.User1;
import com.capg.movietickets.web.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserRepository userrepository;

	@Override
	public User1 save(User1 id) {
		// TODO Auto-generated method stub
		userrepository.save(id);
		return userrepository.save(id);
	}

	public User1 findById(int id) {
		return userrepository.findOne(id);

	}

	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		// userrepository.delete(id);
		userrepository.delete(id);

	}

	@Override
	public List<User1> retriveAll() {

		return userrepository.findAll();
	}

}
