package com.capg.movietickets.web.service;

import com.capg.movietickets.web.model.Booking1;
import com.capg.movietickets.web.visualobjects.BookingVo;
import com.capg.movietickets.web.visualobjects.TicketsVO;

public interface BookingService {
	

	public Booking1 createBooking(BookingVo createbooking);

	public Booking1 viewBookings(TicketsVO viewBooking);

	



}
