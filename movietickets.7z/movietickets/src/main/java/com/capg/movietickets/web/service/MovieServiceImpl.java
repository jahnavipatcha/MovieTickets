package com.capg.movietickets.web.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.movietickets.web.model.Movie1;
import com.capg.movietickets.web.repository.MovieRepository;


@Service
public class MovieServiceImpl implements MovieService {
	
	@Autowired
	MovieRepository movierepository;
	
	
	@Override
	public void save(Movie1 movieId) {
		movierepository.save(movieId);
		
		}

	@Override
	public List<Movie1> getAllMovies() {
		List<Movie1>movies = new ArrayList<>(); 
		 movierepository.findAll().forEach(movies::add);
		 
		 return movies;	
		}

	@Override
	public Movie1 findById(int id) {
		// TODO Auto-generated method stub
		return movierepository.findOne(id);
	}
}
	

/*
 * @Override public String updatemovies(int movieId) { // TODO Auto-generated
 * method stub return "";//movierepository.updatemovienames(movieId,"KGF"); }
 * 
 * @Override public void delete(int movieId) { // TODO Auto-generated method
 * stub movierepository.delete(movieId); }
 * 
 * }
 */